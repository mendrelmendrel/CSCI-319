from . import Mobile
from FSMs import WalkingFSM, AccelerationFSM
from utils import vec, RESOLUTION

from pygame.locals import *

import pygame
import numpy as np


class Kirby(Mobile):
   def __init__(self, position):
      super().__init__(position, "kirby.png")
        
      # Animation variables specific to Kirby
      self.framesPerSecond = 2 
      self.nFrames = 2
      
      self.nFramesList = {
         "moving"   : 4,
         "standing" : 2
      }
      
      self.rowList = {
         "moving"   : 1,
         "standing" : 0
      }
      
      self.framesPerSecondList = {
         "moving"   : 8,
         "standing" : 2
      }
            
      self.FSManimated = WalkingFSM(self)
      self.LR = AccelerationFSM(self, axis=0)
      self.UD = AccelerationFSM(self, axis=1)

      # HP System
      self.maxHp = 4
      self.hp = self.maxHp
      
      # Dash System
      self.isDashing = False
      self.dashTimer = 0
      self.dashDuration = 0.5  # Duration of dash in seconds
      self.dashSpeed = 100000  # Dash velocity
      self.dashDirection = vec(1, 0)  # Direction to dash
      
      # Track held keys for dash direction
      self.keysHeld = {
         'left': False,
         'right': False,
         'up': False,
         'down': False
      }
      
      
   def handleEvent(self, event):
      if event.type == KEYDOWN:
         if event.key == K_UP:
            self.UD.decrease()
            self.keysHeld['up'] = True
             
         elif event.key == K_DOWN:
            self.UD.increase()
            self.keysHeld['down'] = True
            
         elif event.key == K_LEFT:
            self.LR.decrease()
            self.keysHeld['left'] = True
            
         elif event.key == K_RIGHT:
            self.LR.increase()
            self.keysHeld['right'] = True
            
         elif event.key == K_LSHIFT or event.key == K_RSHIFT:
            # Start dash based on held direction keys
            if not self.isDashing:
               self.isDashing = True
               self.dashTimer = 0
               
               # Determine dash direction from held keys
               dashDir = vec(0, 0)
               if self.keysHeld['right']:
                  dashDir[0] = 1
               elif self.keysHeld['left']:
                  dashDir[0] = -1
               
               if self.keysHeld['down']:
                  dashDir[1] = 1
               elif self.keysHeld['up']:
                  dashDir[1] = -1
               
               # If no direction held, dash in the direction Kirby is facing
               if dashDir[0] == 0 and dashDir[1] == 0:
                  dashDir[0] = -1 if self.flipped else 1
               
               self.dashDirection = dashDir
            
      elif event.type == KEYUP:
         if event.key == K_UP:
            self.UD.stop_decrease()
            self.keysHeld['up'] = False
             
         elif event.key == K_DOWN:
            self.UD.stop_increase()
            self.keysHeld['down'] = False
             
         elif event.key == K_LEFT:
            self.LR.stop_decrease()
            self.keysHeld['left'] = False
            
         elif event.key == K_RIGHT:
            self.LR.stop_increase()
            self.keysHeld['right'] = False
   
   def update(self, seconds): 
      self.LR.update(seconds)
      self.UD.update(seconds)
      
      # Handle dash
      if self.isDashing:
         self.dashTimer += seconds
         # Apply dash velocity in the stored dash direction
         self.velocity = self.dashDirection * self.dashSpeed
         
         # End dash after duration
         if self.dashTimer >= self.dashDuration:
            self.isDashing = False
            self.velocity = vec(0, 0)
      
      super().update(seconds)
      
      # Flip sprite based on horizontal movement direction
      if self.velocity[0] < 0:  # Moving left
         self.flipped = True
      elif self.velocity[0] > 0:  # Moving right
         self.flipped = False
   
   
  