from . import Mobile
from FSMs import WalkingFSM
from utils import vec, WORLD_SIZE

class PatrollingEnemy(Mobile):
    def __init__(self, position, minX, maxX, spriteName="kirby.png"):
        super().__init__(position, spriteName)
        
        # Path constraints
        self.minX = minX
        self.maxX = maxX
        self.speed = 100  # pixels per second
        self.velocity = vec(self.speed, 0)  # Start moving right
        
        # Animation variables
        self.framesPerSecond = 2 
        self.nFrames = 2
        
        self.nFramesList = {
            "moving"   : 4,
            "standing" : 2
        }
        
        self.rowList = {
            "moving"   : 1,
            "standing" : 0
        }
        
        self.framesPerSecondList = {
            "moving"   : 8,
            "standing" : 2
        }
        
        self.frame = 0
        self.animationTimer = 0
        self.row = 0
        
        # Animation FSM
        self.FSManimated = WalkingFSM(self)
    
    def update(self, seconds):
        # Move back and forth
        if self.position[0] <= self.minX:
            self.velocity[0] = self.speed  # Move right
            self.flipped = False
        elif self.position[0] >= self.maxX:
            self.velocity[0] = -self.speed  # Move left
            self.flipped = True
        
        super().update(seconds)
        
        # Clamp to world boundaries
        if self.position[0] < 0:
            self.position[0] = 0
            self.velocity[0] = 0
        elif self.position[0] + self.getSize()[0] > WORLD_SIZE[0]:
            self.position[0] = WORLD_SIZE[0] - self.getSize()[0]
            self.velocity[0] = 0
        
        if self.position[1] < 0:
            self.position[1] = 0
            self.velocity[1] = 0
        elif self.position[1] + self.getSize()[1] > WORLD_SIZE[1]:
            self.position[1] = WORLD_SIZE[1] - self.getSize()[1]
            self.velocity[1] = 0