import pygame

from .drawable import Drawable
from .kirby import Kirby
from .enemyKirby import EnemyKirby
from .waddleDee import WaddleDee

from utils import vec, WORLD_SIZE, normalize, magnitude

class GameEngine(object):
    import pygame

    def __init__(self):       
        self.kirby = Kirby((0,0))   
        self.enemies = [
            EnemyKirby((400,100), 300, 500),
            WaddleDee((600, 300), 550, 750)
        ]
        self.size = WORLD_SIZE
        self.background = Drawable((0,0), "background.png")
        self.collisionCooldown = 0
    
    def draw(self, drawSurface):        
        self.background.draw(drawSurface)
        for enemy in self.enemies:
            enemy.draw(drawSurface)
        self.kirby.draw(drawSurface)

         # Draw HP counter
        font = pygame.font.Font(None, 36)
        hp_text = font.render(f"HP: {self.kirby.hp}/{self.kirby.maxHp}", True, (255, 0, 0))
        drawSurface.blit(hp_text, (10, 10))
            
    def handleEvent(self, event):
        self.kirby.handleEvent(event)
    
    def checkCollisions(self):
        # Decrement cooldown
        self.collisionCooldown -= 1
        
        # Get Kirby's collision rect
        kirbyRect = pygame.Rect(self.kirby.position[0], self.kirby.position[1], 
                                self.kirby.getSize()[0], self.kirby.getSize()[1])
        
        # Check collision with each enemy
        for enemy in self.enemies:
            enemyRect = pygame.Rect(enemy.position[0], enemy.position[1],
                                    enemy.getSize()[0], enemy.getSize()[1])
            
            if kirbyRect.colliderect(enemyRect):
                # Only damage if cooldown is over
                if self.collisionCooldown <= 0:
                    self.kirby.hp -= 1
                    self.collisionCooldown = 30
                
                # Calculate direction from enemy to player
                direction = self.kirby.position - enemy.position
                direction_length = magnitude(direction)
                
                if direction_length > 0:
                    direction = normalize(direction)
                
                # Knockback force
                knockback = 200
                
                # Apply opposite velocities
                self.kirby.velocity += direction * knockback
                enemy.velocity -= direction * knockback
    
    def update(self, seconds):
        self.kirby.update(seconds)
        for enemy in self.enemies:
            enemy.update(seconds)
        self.checkCollisions()
        
        Drawable.updateOffset(self.kirby, self.size)
    

